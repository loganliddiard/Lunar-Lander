public interface ICommand {
    void invoke(double elapsedTime);
}
