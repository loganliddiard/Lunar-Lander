package edu.usu.utils;

public record Tuple7<A, B, C, D, E, F, G>(A item1, B item2, C item3, D item4, E item5, F item6, G item7) {}