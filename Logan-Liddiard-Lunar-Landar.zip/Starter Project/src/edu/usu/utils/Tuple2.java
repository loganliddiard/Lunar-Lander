package edu.usu.utils;

public record Tuple2<A, B>(A item1, B item2) {}
