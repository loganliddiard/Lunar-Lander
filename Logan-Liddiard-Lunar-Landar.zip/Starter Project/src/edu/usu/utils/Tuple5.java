package edu.usu.utils;

public record Tuple5<A, B, C, D, E>(A item1, B item2, C item3, D item4, E item5) {}