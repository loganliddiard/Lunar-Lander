package edu.usu.utils;

public record Tuple8<A, B, C, D, E, F, G, H>(A item1, B item2, C item3, D item4, E item5, F item6, G item7, H item8) {}