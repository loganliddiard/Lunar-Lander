package edu.usu.utils;

public record Tuple3<A, B, C>(A item1, B item2, C item3) {}